function load() {
	var mydata = JSON.parse(rsc);
	console.log(mydata);
}